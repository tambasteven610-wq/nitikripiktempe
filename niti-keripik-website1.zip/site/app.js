/* =====================================================================
   NITI KERIPIK TEMPE — logika bersama.
   Data (produk, harga, foto, teks) ada di data.js dan diubah lewat Panel Pemilik (login "Masuk Admin" di footer).
   ===================================================================== */
const D=(()=>{
  let d=window.NITI_DATA,preview=false;
  try{if(localStorage.getItem("niti_preview")==="1"){const dr=JSON.parse(localStorage.getItem("niti_draft")||"null");if(dr&&dr.products){d=dr;preview=true}}}catch(e){}
  d.preview=preview;return d;
})();
const CONFIG=Object.assign({},D.config,{year:new Date().getFullYear()});
const SITE=D.site;
const PRODUCTS=D.products.filter(p=>p.status!=="sembunyi");
const REVIEWS=D.reviews;

/* ---------- util ---------- */
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const rp=n=>"Rp"+Number(n).toLocaleString("id-ID");
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const byId=id=>PRODUCTS.find(p=>p.id===Number(id));
const IC={
  cart:'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h8.2a2 2 0 0 0 2-1.5L21.5 8H6"/></svg>',
  wa:'<svg class="i" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.700 6.700 0 0 1-3.300-2.900c-.2-.4.2-.4.700-1.300.1-.2 0-.3 0-.5l-.8-1.800c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.200c0 1.300.9 2.600 1 2.700.1.200 1.900 2.900 4.600 4 1.700.7 2.400.8 3.200.700.5-.1 1.500-.6 1.700-1.200.2-.6.2-1.100.2-1.200-.1-.1-.3-.2-.5-.3z"/></svg>',
  check:'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  pin:'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s7-6.2 7-12a7 7 0 0 0-14 0c0 5.800 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/></svg>',
  clock:'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  arrow:'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'
};
/* peta Google Maps interaktif: terima nama tempat/alamat, atau kode "Sematkan peta" dari Google Maps */
function gmapEmbed(v){v=String(v||"").trim();if(!v)return "";
  const m=v.match(/https:\/\/www\.google\.com\/maps\/embed\?[^"'\s<>]+/);if(m)return m[0].replace(/&amp;/g,"&");
  return "https://maps.google.com/maps?q="+encodeURIComponent(v)+"&z=16&hl=id&output=embed"}
const stars=n=>"★".repeat(Math.round(n))+"☆".repeat(5-Math.round(n));
const waLink=(text)=>`https://wa.me/${CONFIG.waNumber}?text=${encodeURIComponent(text)}`;
const waGeneral=()=>waLink(`Halo ${CONFIG.store}, saya ingin bertanya tentang produk.`);

/* ---------- keranjang ---------- */
let cart=[];
try{cart=JSON.parse(localStorage.getItem("niti_cart_v2")||"[]")}catch(e){}
const saveCart=()=>{try{localStorage.setItem("niti_cart_v2",JSON.stringify(cart))}catch(e){}};
const cartItems=()=>cart.map(c=>({qty:c.qty,p:byId(c.id)})).filter(x=>x.p);
const cartTotal=()=>cartItems().reduce((a,x)=>a+x.qty*x.p.price,0);
const cartCount=()=>cartItems().reduce((a,x)=>a+x.qty,0);

function buildOrderText(items,name,note){
  const total=items.reduce((a,x)=>a+x.qty*x.p.price,0);
  let t=`Halo ${CONFIG.store}, saya ingin memesan:\n\n`;
  items.forEach((x,i)=>{t+=`${i+1}. ${x.p.name} (${x.p.unit})\n    ${x.qty} x ${rp(x.p.price)} = ${rp(x.qty*x.p.price)}\n`});
  t+=`\n*Total belanja: ${rp(total)}* (belum termasuk ongkir)`;
  if(name)t+=`\n\nNama: ${name}`;
  if(note)t+=`\nAlamat/Catatan: ${note}`;
  t+=`\n\nMohon info total dengan ongkir dan cara pembayarannya. Terima kasih!`;
  return t;
}
function toast(m){const t=$("#toast");t.textContent=m;t.classList.add("show");clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove("show"),2000)}
function openCart(o){
  $("#drawer").classList.toggle("open",o);$("#overlay").classList.toggle("show",o);
  $("#drawer").setAttribute("aria-hidden",String(!o));document.body.style.overflow=o?"hidden":"";
}
function renderCart(){
  const items=cartItems();
  const cc=$("#cartCount");cc.textContent=cartCount();cc.style.display=cartCount()?"grid":"none";
  $("#cartTotal").textContent=rp(cartTotal());
  $("#cartFoot").style.display=items.length?"block":"none";
  $("#cartBody").innerHTML=items.length?items.map(({p,qty})=>`
    <div class="c-item">
      <img src="${esc(p.img)}" alt="">
      <div><b>${esc(p.name)}</b><small>${rp(p.price)} · ${esc(p.unit)}</small><br>
        <div class="qty"><button data-dec="${p.id}" aria-label="Kurangi">−</button><span>${qty}</span><button data-inc="${p.id}" aria-label="Tambah">+</button></div></div>
      <div class="sub">${rp(p.price*qty)}<br><button class="rm" data-rm="${p.id}">Hapus</button></div>
    </div>`).join(""):`<div class="empty"><span class="e">🛒</span>Keranjang masih kosong.<br>Yuk pilih keripik favoritmu!<br><br><a class="btn btn-red btn-sm" href="produk.html">Lihat Katalog</a></div>`;
  saveCart();
}
function addToCart(id,d=1,silent){
  const i=cart.find(c=>c.id===id);
  if(i){i.qty+=d;if(i.qty<=0)cart=cart.filter(c=>c.id!==id)}else if(d>0)cart.push({id,qty:d});
  renderCart();
  if(d>0){const b=$("#cartCount");b.classList.remove("bump");void b.offsetWidth;b.classList.add("bump");
    if(!silent)toast("✓ "+byId(id).name+" masuk keranjang")}
}
function checkout(){
  const items=cartItems();if(!items.length)return;
  const text=buildOrderText(items,$("#custName").value.trim(),$("#custNote").value.trim());
  window.open(waLink(text),"_blank","noopener");
}

/* ---------- layout bersama ---------- */
const NAV=[["index.html","Beranda"],["produk.html","Produk"],["kenali.html","Kenali Niti"],["ulasan.html","Ulasan Pelanggan"],["tentang.html","Cerita Kami"]];
function mountLayout(){
  const page=document.body.dataset.page;
  const top=`<div class="topbar">${esc(SITE.topbar)}</div>
  <header class="site-header">
    <a href="index.html" class="brand"><img class="brand-logo" src="img/logo-niti.png" alt="Logo Niti"><span><b>Niti Keripik Tempe</b><small>TERKENAL SEJAK TH 1967</small></span></a>
    <nav class="main-nav" id="nav">${NAV.map(([h,l])=>`<a href="${h}" class="${h.startsWith(page)?"active":""}">${l}</a>`).join("")}<a class="btn btn-wa nav-cta" href="${waGeneral()}" target="_blank" rel="noopener">${IC.wa} Pesan via WhatsApp</a></nav>
    <div class="head-actions">
      <button class="cart-btn" id="openCart" aria-label="Buka keranjang">${IC.cart}<span class="cart-count" id="cartCount">0</span></button>
      <a class="btn btn-red btn-sm" href="${waGeneral()}" target="_blank" rel="noopener">${IC.wa} Pesan via WhatsApp</a>
      <button class="menu-toggle" id="menuToggle" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
    </div>
  </header>`;
  document.body.insertAdjacentHTML("afterbegin",top);
  const foot=`<footer class="site-footer"><div class="wrap">
    <div class="f-grid">
      <div><a href="index.html" class="brand" style="margin-bottom:12px"><img class="brand-logo" src="img/logo-niti.png" alt="Logo Niti"><span><b>Niti Keripik Tempe</b></span></a>
        <p>Melestarikan resep tradisional otentik keripik tempe gurih, renyah, dan tanpa pengawet sejak tahun 1967.</p></div>
      <div><h4>Tautan Cepat</h4><ul>${NAV.map(([h,l])=>`<li><a href="${h}">${l}</a></li>`).join("")}</ul></div>
      <div><h4>Layanan Pelanggan</h4><ul><li>Senin – Minggu: 08.00 – 21.00 WIB</li><li><a href="${waGeneral()}" target="_blank" rel="noopener">WhatsApp ${CONFIG.waDisplay}</a></li><li><a href="${CONFIG.instagram}" target="_blank" rel="noopener">Instagram ${CONFIG.instagramHandle}</a></li></ul></div>
      <div><h4>Jaminan Kualitas</h4><ul><li>✓ 100% kedelai alami pilihan</li><li>✓ Tanpa pengawet buatan</li><li>✓ Pengiriman aman seluruh Nusantara</li><li>PIRT terdaftar · Halal</li></ul></div>
    </div>
    <div class="f-bottom"><span>© 1967 – ${CONFIG.year} ${CONFIG.store}. Tradisi rasa otentik Indonesia. · <button type="button" class="admin-link" data-admin>Masuk Admin</button></span><span>${esc(CONFIG.address.split(",").slice(0,2).join(","))}</span></div></div></footer>
  <a class="float-wa" href="${waGeneral()}" target="_blank" rel="noopener" aria-label="Chat WhatsApp">${IC.wa}</a>
  <div class="overlay" id="overlay"></div>
  <aside class="drawer" id="drawer" aria-label="Keranjang belanja" aria-hidden="true">
    <div class="d-head"><h3>Keranjang Belanja</h3><button class="icon-btn" id="closeCart" aria-label="Tutup">✕</button></div>
    <div class="d-body" id="cartBody"></div>
    <div class="d-foot" id="cartFoot">
      <label for="custName">Nama</label><input id="custName" placeholder="Nama Anda" autocomplete="name">
      <label for="custNote">Alamat lengkap / catatan</label><textarea id="custNote" placeholder="Alamat pengiriman, kecamatan, catatan lain"></textarea>
      <div class="total"><span>Total</span><b id="cartTotal">Rp0</b></div>
      <p class="note">Belum termasuk ongkos kirim. Ongkir dihitung admin saat konfirmasi.</p>
      <button class="btn btn-wa btn-block" id="checkout">${IC.wa} Checkout via WhatsApp</button>
      <button class="clear" id="clearCart">Kosongkan keranjang</button>
    </div>
  </aside>
  <div class="toast" id="toast" role="status"></div>`;
  document.body.insertAdjacentHTML("beforeend",foot);
}

/* ---------- komponen ---------- */
function productCard(p){
  return `<article class="pcard">
    <a class="pic" href="produk.html?p=${p.id}" aria-label="${esc(p.name)}"><img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy"></a>
    <div class="body">
      <div class="rating">${stars(p.rating)} <small>${p.rating.toFixed(1)} (${p.sold} terjual)</small></div>
      <h3><a href="produk.html?p=${p.id}">${esc(p.name)}</a></h3>
      <p class="desc">${esc(p.desc)}</p>
      <div class="price"><b>${rp(p.price)}</b>${p.old?`<s>${rp(p.old)}</s>`:""}</div>
      <div class="unit">${esc(p.unit)}</div>
      <div class="acts">${p.status==="habis"?`<button class="btn btn-sm" disabled style="background:#e6ddd6;color:#8a7b72;cursor:not-allowed">Stok Habis</button>`:`<button class="btn btn-red btn-sm" data-add="${p.id}">${IC.cart} + Keranjang</button>`}<a class="btn btn-line btn-sm" href="produk.html?p=${p.id}">Detail</a></div>
    </div></article>`;
}
function reviewCard(r){
  return `<article class="rcard">
    <div class="who"><span class="avatar ${r.cls}">${r.l}</span><div><b>${esc(r.n)}</b><small>${esc(r.c)}</small></div><span class="vt">✓ Terverifikasi</span></div>
    <div class="stars">${"★".repeat(r.s)}</div><div style="margin:6px 0"><span class="tagp">${esc(r.v)}</span></div>
    <blockquote>“${esc(r.t)}”</blockquote>
    ${r.img?`<img src="${esc(r.img)}" alt="Foto dari ${esc(r.n)}" loading="lazy">`:""}
    <div class="foot"><span>${esc(r.f)}</span><span>${esc(r.w)}</span></div></article>`;
}

/* ---------- halaman ---------- */
function initHome(){
  const el=$("#featured");if(!el)return;
  let f=PRODUCTS.filter(p=>p.featured);if(!f.length)f=PRODUCTS.slice(0,4);
  el.innerHTML=f.slice(0,8).map(productCard).join("");
  const rv=$("#homeReviews");if(rv){let r=REVIEWS.filter(x=>x.home);if(!r.length)r=REVIEWS.slice(0,3);rv.innerHTML=r.slice(0,3).map(reviewCard).join("")}
}
function initCatalog(){
  const root=$("#catalog");if(!root)return;
  const params=new URLSearchParams(location.search);
  const pid=params.get("p");
  if(pid&&byId(pid)){$("#listView").hidden=true;$("#detailView").hidden=false;renderDetail(byId(pid));return}
  const state={q:"",kat:"Semua",price:"all",sort:"pop"};
  const kats=["Semua",...new Set(PRODUCTS.map(p=>p.kat))];
  $("#katOpts").innerHTML=kats.map((k,i)=>`<label class="opt"><input type="radio" name="kat" value="${esc(k)}" ${i?"":"checked"}> ${esc(k)}</label>`).join("");
  const ranges={all:[0,1e12],a:[0,25000],b:[25000,50000],c:[50000,100000],d:[100000,1e12]};
  function draw(){
    const [lo,hi]=ranges[state.price];
    let l=PRODUCTS.filter(p=>(state.kat==="Semua"||p.kat===state.kat)&&p.price>=lo&&p.price<hi&&(!state.q||(p.name+" "+p.desc).toLowerCase().includes(state.q)));
    const sold=p=>parseInt(p.sold);
    if(state.sort==="lo")l.sort((a,b)=>a.price-b.price);
    if(state.sort==="hi")l.sort((a,b)=>b.price-a.price);
    $("#count").textContent=`Menampilkan ${l.length} dari ${PRODUCTS.length} produk`;
    $("#grid").innerHTML=l.length?l.map(productCard).join(""):`<div class="empty-res card" style="grid-column:1/-1">Tidak ada produk yang cocok. Coba ubah filter atau kata kunci.</div>`;
  }
  $("#q").addEventListener("input",e=>{state.q=e.target.value.trim().toLowerCase();draw()});
  $("#sort").addEventListener("change",e=>{state.sort=e.target.value;draw()});
  root.addEventListener("change",e=>{if(e.target.name==="kat"){state.kat=e.target.value;draw()}if(e.target.name==="price"){state.price=e.target.value;draw()}});
  const side=$("#side"),ft=$("#filterToggle");
  ft.onclick=()=>{const o=side.classList.toggle("open");ft.setAttribute("aria-expanded",o)};
  $("#sideDone").onclick=()=>{side.classList.remove("open");ft.setAttribute("aria-expanded","false");$("#grid").scrollIntoView({behavior:"smooth",block:"start"})};
  $("#resetF").onclick=()=>{state.q="";state.kat="Semua";state.price="all";$("#q").value="";$$("input[name=kat]")[0].checked=true;$("input[name=price][value=all]").checked=true;draw()};
  draw();
}
function renderDetail(p){
  document.title=`${p.name} — ${CONFIG.store}`;
  const gal=p.gallery||[p.img];
  let qty=1;const out=p.status==="habis";
  const bucket=[[1,"1 Bungkus"],[2,"2 Bungkus"],[3,"3 Bungkus"],[5,"5 Bungkus (Hemat)"],[10,"10 Bungkus (Grosir)"]];
  $("#crumbName").textContent=p.name;
  const feats=(p.taste||[]).map(t=>`<div><b>${esc(t[0])}</b>${esc(t[1])}</div>`).join("");
  $("#detail").innerHTML=`
    <div class="gallery"><div class="main"><img id="mainImg" src="${esc(gal[0])}" alt="${esc(p.name)}"></div>
      ${gal.length>1?`<div class="thumbs">${gal.slice(1).map((g,i)=>`<button data-g="${esc(g)}" aria-label="Foto ${i+1}"><img src="${esc(g)}" alt=""></button>`).join("")}</div>`:""}</div>
    <div>
      <div class="meta"><span>SKU: ${esc(p.sku)} · Kategori: ${esc(p.kat)}</span><span class="rating">${stars(p.rating)} <b style="color:var(--ink)">${p.rating.toFixed(1)}</b> <small>(${p.sold} ulasan)</small></span></div>
      <h1>${esc(p.name)} <small>(${esc(p.unit)})</small></h1>
      <div class="pricebox"><div class="price"><b>${rp(p.price)}</b>${p.old?`<s>${rp(p.old)}</s>`:""}<span style="font-size:12px;color:var(--muted)">/ ${esc(p.unit)}</span></div><span class="ready"${out?' style="background:#f3d6d1;color:#a9170b"':""}>${out?"Stok Habis":"Siap Kirim"}</span></div>
      <p style="color:var(--muted);font-size:14px">${esc(p.long||p.desc)}</p>
      ${feats?`<div class="feats">${feats}</div>`:""}
      <div class="qtyline"><span>Pilih jumlah paket:</span><span>Total: <b id="dTotal" style="color:var(--red)">${rp(p.price)}</b></span></div>
      <div class="qchips" id="qchips">${bucket.map(([n,l])=>`<button data-q="${n}" class="${n===1?"on":""}">${l}</button>`).join("")}</div>
      <div class="buy-actions">
        ${out?`<button class="btn btn-block" disabled style="background:#e6ddd6;color:#8a7b72;cursor:not-allowed">Stok Sedang Habis</button>`:`<button class="btn btn-red btn-block" id="dAdd">${IC.cart} Tambah ke Keranjang</button>
        <button class="btn btn-wa btn-block" id="dBuy">${IC.wa} Beli Sekarang via WhatsApp</button>`}
        <div class="row"><a class="btn btn-line btn-sm" id="dAsk" target="_blank" rel="noopener">Tanyakan Produk</a><button class="btn btn-line btn-sm" id="dShare">Bagikan Produk</button></div>
      </div>
      <div class="assure"><span>${IC.check} Kemasan zipper kedap udara</span><span>${IC.check} Packing bubble wrap tebal</span><span>${IC.check} Garansi renyah 100%</span></div>
    </div>`;
  if(!out){const sb=document.createElement("div");sb.className="sticky-buy";sb.id="stickyBuy";
  sb.innerHTML=`<div class="tot"><small>Total</small><b id="sTotal">${rp(p.price)}</b></div><button class="btn btn-red" id="sAdd">${IC.cart} Keranjang</button><button class="btn btn-wa" id="sBuy">${IC.wa} Beli</button>`;
  document.body.appendChild(sb);document.body.classList.add("has-sticky")}
  const upd=()=>{$("#dTotal").textContent=rp(p.price*qty);const sT=$("#sTotal");if(sT)sT.textContent=rp(p.price*qty)};
  $("#qchips").addEventListener("click",e=>{const b=e.target.closest("[data-q]");if(!b)return;qty=+b.dataset.q;$$("#qchips button").forEach(x=>x.classList.toggle("on",x===b));upd()});
  $$(".thumbs button").forEach(b=>b.onclick=()=>{$("#mainImg").src=b.dataset.g;$$(".thumbs button").forEach(x=>x.classList.toggle("on",x===b))});
  if(!out){$("#dAdd").onclick=()=>{addToCart(p.id,qty,true);toast(`✓ ${qty} × ${p.name} masuk keranjang`);openCart(true)};
  const buyNow=()=>window.open(waLink(buildOrderText([{p,qty}],"","")),"_blank","noopener");
  $("#dBuy").onclick=buyNow;$("#sBuy").onclick=buyNow;
  $("#sAdd").onclick=()=>{addToCart(p.id,qty,true);toast(`✓ ${qty} × ${p.name} masuk keranjang`);openCart(true)}}
  $("#dAsk").href=waLink(`Halo ${CONFIG.store}, saya ingin bertanya tentang produk "${p.name}".`);
  $("#dShare").onclick=async()=>{const u=location.href;try{if(navigator.share){await navigator.share({title:p.name,url:u})}else{await navigator.clipboard.writeText(u);toast("Tautan produk disalin")}}catch(e){}};
  const info=$("#infoCard");
  if(p.spec){info.hidden=false;info.innerHTML=`<span class="pill">Standar Kualitas Autentik 1967</span><h2>Karakteristik & Komposisi Pilihan</h2><p style="color:var(--muted);margin:0">${esc(p.long)}</p><div class="spec-grid">${p.spec.map(s=>`<div class="spec"><b>${esc(s[0])}</b><strong style="font-size:14px">${esc(s[1])}</strong><small>${esc(s[2])}</small></div>`).join("")}</div>`}
  const rel=PRODUCTS.filter(x=>x.id!==p.id).slice(0,4);
  $("#related").innerHTML=rel.map(productCard).join("");
}
function initReviews(){
  const g=$("#rvgrid");if(!g)return;
  let f="all";
  const draw=()=>{const l=REVIEWS.filter(r=>f==="all"||(f==="foto"&&r.img)||(f==="5"&&r.s===5));g.innerHTML=l.map(reviewCard).join("")};
  $("#rvfilters").addEventListener("click",e=>{const b=e.target.closest("[data-f]");if(!b)return;f=b.dataset.f;$$("#rvfilters .chip").forEach(x=>x.classList.toggle("on",x===b));draw()});
  draw();
  let rating=5;const sp=$("#starpick");
  const labels=["","Sangat Kurang","Kurang","Cukup","Bagus","Sangat Memuaskan"];
  const paint=()=>{$$("button",sp).forEach((b,i)=>b.classList.toggle("on",i<rating));$("#starLabel").textContent=`${rating} Bintang (${labels[rating]})`};
  sp.innerHTML=[1,2,3,4,5].map(i=>`<button type="button" data-s="${i}" aria-label="${i} bintang">★</button>`).join("");
  sp.addEventListener("click",e=>{const b=e.target.closest("[data-s]");if(b){rating=+b.dataset.s;paint()}});paint();
  $("#rvForm").addEventListener("submit",e=>{
    e.preventDefault();const d=new FormData(e.target);
    const t=`Halo ${CONFIG.store}, saya ingin berbagi ulasan:\n\nNama: ${d.get("nama")}\nVarian: ${d.get("varian")}\nRating: ${"★".repeat(rating)} (${rating}/5)\n\nUlasan:\n${d.get("isi")}\n\n(Foto produk bisa saya kirim di chat ini.)`;
    window.open(waLink(t),"_blank","noopener");
  });
  const bars=$("#bars");if(bars)bars.innerHTML=[5,4,3,2,1].map((n,i)=>`<div><span>${n}★</span><i><b style="width:${+SITE.bars[i]||0}%"></b></i><small>${+SITE.bars[i]||0}%</small></div>`).join("");
  $("#varian").innerHTML=`<option value="">Pilih varian produk...</option>`+PRODUCTS.map(p=>`<option>${esc(p.name)}</option>`).join("");
}

/* ---------- start ---------- */
function applySite(){
  const em=t=>esc(t).replace(/\*([^*]+)\*/g,"<em>$1</em>");
  $$("[data-site]").forEach(e=>{const v=SITE[e.dataset.site];if(v!=null)e.textContent=v});
  $$("[data-site-title]").forEach(e=>{const v=SITE[e.dataset.siteTitle];if(v!=null)e.innerHTML=em(v)});
  $$("[data-site-img]").forEach(e=>{const v=SITE[e.dataset.siteImg];if(v)e.src=v});
  $$("[data-cfg]").forEach(e=>{const v=CONFIG[e.dataset.cfg];if(v!=null)e.textContent=v});
  if(D.preview){document.body.insertAdjacentHTML("beforeend",'<div id="pvbar" style="position:fixed;left:12px;top:12px;z-index:90;background:#fff3c4;border:1px solid #e9c24a;color:#5a3d00;padding:9px 14px;border-radius:10px;font:600 12.5px var(--sans);box-shadow:0 6px 18px #0003;max-width:calc(100vw - 24px)">Mode pratinjau: perubahan belum terbit. <a href="#" data-admin style="text-decoration:underline">Kembali ke admin</a> · <a href="#" id="pvOff" style="text-decoration:underline">Keluar</a></div>');
    $("#pvOff").onclick=e=>{e.preventDefault();try{localStorage.removeItem("niti_preview")}catch(_){}location.reload()}}
}
document.addEventListener("DOMContentLoaded",()=>{
  mountLayout();applySite();
  $$("[data-wa]").forEach(a=>{a.href=waGeneral();a.target="_blank";a.rel="noopener"});
  $$("[data-wa-text]").forEach(a=>{a.href=waLink(a.dataset.waText);a.target="_blank";a.rel="noopener"});
  $$("[data-addr]").forEach(e=>e.textContent=CONFIG.address);
  $$("[data-maps]").forEach(a=>{a.href=CONFIG.mapsUrl;a.target="_blank";a.rel="noopener"});
  $$("[data-gmap]").forEach(f=>{const u=gmapEmbed(CONFIG.mapsQuery||CONFIG.address);if(u&&f.src!==u)f.src=u});
  $$("[data-ig]").forEach(a=>{a.href=CONFIG.instagram;a.target="_blank";a.rel="noopener"});
  $$("[data-tt]").forEach(a=>{a.href=CONFIG.tiktok;a.target="_blank";a.rel="noopener"});
  $$("[data-wanum]").forEach(e=>e.textContent=CONFIG.waDisplay);
  initHome();initCatalog();initReviews();
  renderCart();
  document.addEventListener("click",e=>{
    const a=e.target.closest("[data-add]");if(a)return addToCart(+a.dataset.add,1);
    const inc=e.target.closest("[data-inc]");if(inc)return addToCart(+inc.dataset.inc,1,true);
    const dec=e.target.closest("[data-dec]");if(dec)return addToCart(+dec.dataset.dec,-1,true);
    const ad=e.target.closest("[data-admin]");if(ad){e.preventDefault();return NitiAdmin.open()}
    const rm=e.target.closest("[data-rm]");if(rm){cart=cart.filter(c=>c.id!==+rm.dataset.rm);renderCart()}
  });
  $("#openCart").onclick=()=>openCart(true);
  $("#closeCart").onclick=$("#overlay").onclick=()=>openCart(false);
  document.addEventListener("keydown",e=>{if(e.key==="Escape")openCart(false)});
  $("#checkout").onclick=checkout;
  $("#clearCart").onclick=()=>{cart=[];renderCart()};
  $("#menuToggle").onclick=function(){const o=$("#nav").classList.toggle("open");this.setAttribute("aria-expanded",o)};
  if(/^#admin$/i.test(location.hash)||new URLSearchParams(location.search).has("admin"))NitiAdmin.open();
});

/* =====================================================================
   PANEL PEMILIK (ADMIN) — tergabung di situs, dibuka lewat login.
   Tautan "Masuk Admin" ada di bagian bawah footer, atau buka alamat situs + #admin.
   Login bawaan: admin / niti1967 (ganti di menu Info Toko > Akun Admin, lalu terbitkan data.js).
   ===================================================================== */
const NitiAdmin=(()=>{
const DEFAULT_HASH="a09df6ca62ef277a738a0f2ea01e5914438698f0c0f67eed9e92ef96dcd98ecd"; /* sha256("niti|admin|niti1967") */
const SKEY="niti_admin_session";
/* SHA-256 (murni JS, agar berjalan juga di file:// dan http biasa) */
const sha256=(()=>{const K=[],H0=[];let n=2,c=0;const fr=x=>((x-Math.floor(x))*4294967296)>>>0;
  while(c<64){let p=true;for(let d=2;d*d<=n;d++)if(n%d===0){p=false;break}if(p){if(c<8)H0[c]=fr(Math.pow(n,1/2));K[c]=fr(Math.pow(n,1/3));c++}n++}
  const r=(x,k)=>(x>>>k)|(x<<(32-k));
  return str=>{const b=[...new TextEncoder().encode(str)],l=b.length*8;b.push(0x80);while(b.length%64!==56)b.push(0);
    for(let i=7;i>=0;i--)b.push(i>=4?0:(l>>>(i*8))&255);
    const H=H0.slice(),W=new Array(64);
    for(let o=0;o<b.length;o+=64){
      for(let i=0;i<16;i++)W[i]=(b[o+4*i]<<24)|(b[o+4*i+1]<<16)|(b[o+4*i+2]<<8)|b[o+4*i+3];
      for(let i=16;i<64;i++){const s0=r(W[i-15],7)^r(W[i-15],18)^(W[i-15]>>>3),s1=r(W[i-2],17)^r(W[i-2],19)^(W[i-2]>>>10);W[i]=(W[i-16]+s0+W[i-7]+s1)|0}
      let[a,bb,cc,d,e,f,g,hh]=H;
      for(let i=0;i<64;i++){const t1=(hh+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[i]+W[i])|0,t2=((r(a,2)^r(a,13)^r(a,22))+((a&bb)^(a&cc)^(bb&cc)))|0;hh=g;g=f;f=e;e=(d+t1)|0;d=cc;cc=bb;bb=a;a=(t1+t2)|0}
      [a,bb,cc,d,e,f,g,hh].forEach((v,i)=>H[i]=(H[i]+v)|0)}
    return H.map(x=>(x>>>0).toString(16).padStart(8,"0")).join("")}})();
const credHash=(u,p)=>sha256("niti|"+String(u).trim().toLowerCase()+"|"+p);
const draftData=()=>{try{const d=JSON.parse(localStorage.getItem("niti_draft")||"null");if(d&&d.products)return d}catch(e){}return null};
/* login dicek terhadap data situs yang terbit DAN draft di perangkat ini (agar password baru langsung bisa dipakai di perangkat yang sama) */
const validHashes=()=>[...new Set([(window.NITI_DATA.config||{}).adminHash||DEFAULT_HASH,((draftData()||{}).config||{}).adminHash].filter(Boolean))];
const isIn=()=>{try{return sessionStorage.getItem(SKEY)==="1"}catch(e){return false}};
const setIn=v=>{try{v?sessionStorage.setItem(SKEY,"1"):sessionStorage.removeItem(SKEY)}catch(e){}};

const CSS=`
:host{all:initial;position:fixed;inset:0;z-index:1000;display:block;overflow:auto;-webkit-overflow-scrolling:touch;
--red:#c91c0c;--red-d:#a9170b;--ink:#211b18;--muted:#71625b;--cream:#fbf7f4;--tint:#f5eeea;--line:#e4d8cf;--green:#1fa855;--gold:#ffc940;--serif:'Playfair Display',Georgia,serif;--sans:'DM Sans',Arial,sans-serif;
background:var(--cream);color:var(--ink);font:15px/1.55 var(--sans);-webkit-font-smoothing:antialiased}
*{box-sizing:border-box}
button,input,select,textarea{font:inherit;color:inherit}button{cursor:pointer}img{display:block;max-width:100%}
.btn{min-height:44px;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;border-radius:8px;padding:0 18px;font-weight:600;font-size:14px;background:#fff;border-color:var(--line);transition:.15s;text-align:center;white-space:nowrap;text-decoration:none}
.btn:hover{border-color:#c9b8ad}
.btn.red{background:var(--red);border-color:var(--red);color:#fff}.btn.red:hover{background:var(--red-d)}
.btn.sm{min-height:40px;padding:0 13px;font-size:13px}.btn.danger{color:var(--red)}
.btn.icon{width:40px;padding:0}.btn.block{width:100%}
header.top{position:sticky;top:0;z-index:20;background:rgba(255,253,250,.97);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);padding:calc(10px + env(safe-area-inset-top)) 16px 0}
.bar{max-width:1120px;margin:auto;display:flex;align-items:center;justify-content:space-between;gap:12px;padding-bottom:10px}
.brand{display:flex;align-items:center;gap:10px;min-width:0}.logo{height:34px;width:auto;flex:none}
.brand b{display:block;font:600 17px var(--serif);line-height:1.2}.brand small{display:block;font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.show-m{display:none}.hacts{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#1c9a4e;margin-right:6px}.dot.warn{background:#e9a52c}
.tabs{max-width:1120px;margin:auto;display:flex;gap:6px;overflow-x:auto;scrollbar-width:none}.tabs::-webkit-scrollbar{display:none}
.tabs button{border:0;background:none;padding:12px 16px;font-weight:600;font-size:14px;color:#7a6a61;border-bottom:3px solid transparent;white-space:nowrap;min-height:46px}
.tabs button.on{color:var(--red);border-color:var(--red)}
main{max-width:1120px;margin:auto;padding:22px 16px 90px}
.panel{display:none}.panel.on{display:block}
.head{display:flex;justify-content:space-between;align-items:flex-end;gap:14px;flex-wrap:wrap;margin-bottom:16px}
.head h2{margin:0;font:600 24px var(--serif)}.head p{margin:2px 0 0;color:var(--muted);font-size:13.5px}
.tools{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.search{min-height:44px;border:1px solid var(--line);border-radius:8px;padding:0 14px;background:#fff;min-width:200px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.card{background:#fff;border:1px solid var(--line);border-radius:12px;overflow:hidden}
.pc{display:flex;flex-direction:column}.pc .ph{aspect-ratio:1.4/1;background:var(--tint);overflow:hidden}.pc .ph img{width:100%;height:100%;object-fit:cover}
.pc .b{padding:12px 14px;display:flex;flex-direction:column;gap:6px;flex:1}.pc h3{margin:0;font:600 16px var(--serif);line-height:1.3}
.price{font:600 17px var(--serif);color:var(--red)}.price s{font:12px var(--sans);color:#9a8c83;margin-left:6px}
.chips{display:flex;gap:6px;flex-wrap:wrap}.chip{font-size:11px;font-weight:700;padding:2px 9px;border-radius:20px;background:#e8f6ee;color:#17743c}.chip.out{background:#fde4e0;color:#a9170b}.chip.hide{background:#eee;color:#666}.chip.fe{background:#fff0c2;color:#7a5200}
.acts{display:flex;gap:6px;flex-wrap:wrap;margin-top:auto;padding-top:8px}
.rc{padding:14px 16px;display:flex;flex-direction:column;gap:8px}.rc .who{display:flex;gap:10px;align-items:center}.av{width:38px;height:38px;border-radius:10px;background:#ffe0d9;color:#9e2012;display:grid;place-items:center;font:500 17px Roboto,Arial,sans-serif;flex:none}
.rc p{margin:0;color:#202124;font:14px/20px 'Google Sans Text','Google Sans',Roboto,Arial,sans-serif;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.st{color:#fbbc04;letter-spacing:1px}
.empty{padding:40px;text-align:center;color:var(--muted);border:2px dashed var(--line);border-radius:12px;grid-column:1/-1;background:#fff}
.fgrp{background:#fff;border:1px solid var(--line);border-radius:12px;padding:20px;margin-bottom:16px}
.fgrp>h3{margin:0 0 4px;font:600 18px var(--serif)}.fgrp>p.d{margin:0 0 14px;color:var(--muted);font-size:13px}
.row{display:grid;grid-template-columns:1fr 1fr;gap:14px}.row.three{grid-template-columns:repeat(3,1fr)}
.f{margin-bottom:14px}.f label,.f .l{display:block;font-size:12.5px;font-weight:700;color:#5f4c43;margin-bottom:5px}
.f input[type=text],.f input[type=number],.f input[type=url],.f input[type=tel],.f input[type=password],.f select,.f textarea{width:100%;min-height:44px;border:1px solid var(--line);border-radius:8px;padding:10px 12px;background:var(--cream);font-size:15px}
.f textarea{min-height:92px;resize:vertical;line-height:1.5}.f input:focus,.f select:focus,.f textarea:focus{outline:2px solid #f0b3aa;border-color:var(--red);background:#fff}
.hint{display:block;font-size:12px;color:var(--muted);margin-top:4px}
label.chk{display:flex;gap:10px;align-items:center;min-height:44px;font-weight:600;font-size:14px;margin:0;color:var(--ink)}.chk input{width:22px;height:22px;accent-color:var(--red)}
.imgp{display:grid;grid-template-columns:110px 1fr;gap:12px;align-items:start;padding:10px;border:1px dashed #cdbdb1;border-radius:10px;background:#fffdfa}
.imgp .prev{width:110px;height:110px;border-radius:8px;object-fit:cover;background:var(--tint);border:1px solid var(--line)}
.imgp .ia{display:flex;flex-direction:column;gap:8px;min-width:0}.imgp .ia .r{display:flex;gap:8px;flex-wrap:wrap}
.imgp details summary{font-size:12px;color:var(--muted);cursor:pointer;padding:6px 0}.imgp details input{width:100%;min-height:40px;border:1px solid var(--line);border-radius:8px;padding:8px 10px;font-size:14px}
.gal{display:grid;gap:10px}.gal .it{position:relative}.gal .it .x{position:absolute;top:8px;right:8px}
.mapprev{width:100%;height:240px;border:1px solid var(--line);border-radius:10px;background:#e8eaed;display:block}
dialog{border:0;padding:0;border-radius:16px;width:min(760px,94vw);max-height:92vh;box-shadow:0 30px 80px #0006;background:var(--cream);color:var(--ink)}
dialog::backdrop{background:#1b0f0acc}
dialog form{display:flex;flex-direction:column;max-height:92vh;margin:0}
.dh{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid var(--line);background:#fff;border-radius:16px 16px 0 0}.dh h3{margin:0;font:600 20px var(--serif)}
.db{padding:20px;overflow:auto;flex:1;-webkit-overflow-scrolling:touch}
.df{display:flex;gap:10px;justify-content:flex-end;padding:14px 20px calc(14px + env(safe-area-inset-bottom));border-top:1px solid var(--line);background:#fff;border-radius:0 0 16px 16px}
.db h4{margin:20px 0 10px;font:700 12px var(--sans);letter-spacing:.12em;text-transform:uppercase;color:#8a7b72}.db h4:first-child{margin-top:0}
.steps{counter-reset:s;display:grid;gap:12px;margin:0;padding:0;list-style:none}.steps li{counter-increment:s;display:grid;grid-template-columns:34px 1fr;gap:12px;align-items:start}
.steps li::before{content:counter(s);width:34px;height:34px;border-radius:50%;background:var(--red);color:#fff;display:grid;place-items:center;font:600 16px var(--serif)}
.pub{display:grid;grid-template-columns:1.1fr .9fr;gap:16px}.pubbtns{display:grid;gap:10px}
.stat{display:flex;gap:18px;flex-wrap:wrap;margin:10px 0 0}.stat div b{display:block;font:600 24px var(--serif);color:var(--red)}.stat div small{color:var(--muted);font-size:12px}
.toast{position:fixed;left:50%;bottom:calc(20px + env(safe-area-inset-bottom));transform:translate(-50%,30px);background:#2c1912;color:#fff;padding:12px 20px;border-radius:30px;font-size:14px;opacity:0;pointer-events:none;transition:.25s;z-index:200;max-width:92vw;text-align:center}.toast.on{opacity:1;transform:translate(-50%,0)}.toast.err{background:#a9170b}
.note{background:#fff8e1;border:1px solid #f0d98a;border-radius:10px;padding:12px 14px;font-size:13px;color:#5c4400}
/* login */
.login{min-height:100%;display:grid;place-items:center;padding:24px 16px;background:radial-gradient(circle at 30% 0,#fff3e6,var(--cream) 60%)}
.lbox{width:min(400px,100%);background:#fff;border:1px solid var(--line);border-radius:16px;padding:28px 26px;box-shadow:0 20px 50px #47271414}
.lbox .logo{height:56px;margin:0 auto 10px}.lbox h2{margin:0;text-align:center;font:600 22px var(--serif)}.lbox p.s{margin:4px 0 20px;text-align:center;color:var(--muted);font-size:13.5px}
.pw{position:relative}.pw input{padding-right:84px!important}.pw button{position:absolute;right:6px;top:6px;min-height:32px;border:0;background:var(--tint);border-radius:6px;padding:0 10px;font-size:12px;font-weight:600}
.err{display:none;background:#fde4e0;color:#a9170b;border-radius:8px;padding:9px 12px;font-size:13px;margin-bottom:12px}.err.on{display:block}
.back{display:block;text-align:center;margin-top:14px;font-size:13px;color:var(--muted);background:none;border:0;text-decoration:underline;width:100%}
@media(max-width:1000px){.pub{grid-template-columns:1fr}.grid{gap:12px}}
@media(max-width:700px){
  main{padding:16px 14px 90px}.grid{grid-template-columns:1fr;gap:12px}
  .pc{flex-direction:row}.pc .ph{width:104px;aspect-ratio:auto;flex:none}.pc .b{padding:10px 12px}
  .brand small,.brand .logo{display:none}.head h2{font-size:21px}.tools{width:100%}.tools .search{flex:1;min-width:0}.tools .btn{flex:none}
  .hacts{flex-wrap:nowrap;gap:6px}.hacts .btn{padding:0 9px;font-size:12.5px;min-height:38px}.brand b{font-size:15px;white-space:nowrap}header.top{padding-left:12px;padding-right:12px}.hacts .hide-m{display:none}.hacts .show-m{display:inline}
  .row,.row.three{grid-template-columns:1fr;gap:0}.fgrp{padding:16px}
  .imgp{grid-template-columns:84px 1fr}.imgp .prev{width:84px;height:84px}
  dialog{width:100vw;max-width:100vw;height:100dvh;max-height:100dvh;border-radius:0;margin:0}dialog form{max-height:100dvh;height:100dvh}.dh,.df{border-radius:0}
  .df .btn{flex:1}.db{padding:16px}
  .tabs button{padding:12px 13px}
}`;

let host=null,R=null,built=false,D=null,BASE=null,hadDraft=false;
const $=(s,r=R)=>r.querySelector(s),$$=(s,r=R)=>[...r.querySelectorAll(s)];
const clone=o=>JSON.parse(JSON.stringify(o));
const rp=n=>"Rp"+Number(n||0).toLocaleString("id-ID");
const PH="data:image/svg+xml;utf8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" fill="#f1e7e0"/><text x="100" y="112" font-size="46" text-anchor="middle">📷</text></svg>');
function h(tag,props={},...kids){const e=document.createElement(tag);for(const[k,v]of Object.entries(props||{})){if(v==null||v===false)continue;
  if(k==="class")e.className=v;else if(k==="html")e.innerHTML=v;else if(k.startsWith("on"))e.addEventListener(k.slice(2),v);else if(k==="value")e.value=v;else if(k==="checked")e.checked=!!v;else e.setAttribute(k,v===true?"":v)}
  kids.flat().forEach(c=>{if(c!=null&&c!==false)e.append(c.nodeType?c:document.createTextNode(c))});return e}
let tt;function toast(m,err){const t=$("#atoast");t.textContent=m;t.className="toast on"+(err?" err":"");clearTimeout(tt);tt=setTimeout(()=>t.className="toast",2600)}

/* ---------- buka / tutup ---------- */
function ensureHost(){if(host)return;host=document.createElement("div");host.id="niti-admin";host.setAttribute("role","dialog");host.setAttribute("aria-label","Panel Pemilik");
  R=host.attachShadow({mode:"open"});R.innerHTML=`<style>${CSS}</style><div id="view"></div><div class="toast" id="atoast" role="status"></div><dialog id="dlg"></dialog>`;
  document.body.appendChild(host)}
function open(){ensureHost();host.style.display="block";document.documentElement.style.overflow="hidden";
  try{if(location.hash!=="#admin")history.replaceState(null,"",location.pathname+location.search+"#admin")}catch(e){}
  if(isIn())showPanel();else showLogin()}
function close(){if(!host)return;if(built)persist();host.style.display="none";document.documentElement.style.overflow="";
  try{history.replaceState(null,"",location.pathname+location.search)}catch(e){}}
function logout(){if(built)persist();setIn(false);built=false;close();if(D_preview())location.reload()}
const D_preview=()=>{try{return localStorage.getItem("niti_preview")==="1"}catch(e){return false}};

function showLogin(){const v=$("#view");v.innerHTML="";
  const u=h("input",{type:"text",id:"lu",autocomplete:"username",autocapitalize:"none",spellcheck:"false",placeholder:"Username",required:true});
  const p=h("input",{type:"password",id:"lp",autocomplete:"current-password",placeholder:"Password",required:true});
  const eye=h("button",{type:"button",onclick:()=>{const s=p.type==="password";p.type=s?"text":"password";eye.textContent=s?"Sembunyikan":"Lihat"}},"Lihat");
  const err=h("div",{class:"err",role:"alert"});
  const form=h("form",{class:"lbox",onsubmit:e=>{e.preventDefault();
      if(validHashes().includes(credHash(u.value,p.value))){setIn(true);p.value="";showPanel();toast("Selamat datang di Panel Pemilik")}
      else{err.textContent="Username atau password salah.";err.classList.add("on");p.value="";p.focus()}}},
    h("img",{class:"logo",src:"img/logo-niti.png",alt:"Niti"}),h("h2",{},"Masuk Panel Pemilik"),h("p",{class:"s"},"Khusus pemilik / admin Niti Keripik Tempe."),err,
    h("div",{class:"f"},h("label",{for:"lu"},"Username"),u),
    h("div",{class:"f"},h("label",{for:"lp"},"Password"),h("div",{class:"pw"},p,eye)),
    h("button",{type:"submit",class:"btn red block"},"Masuk"),
    h("button",{type:"button",class:"back",onclick:close},"← Kembali ke situs"));
  v.append(h("div",{class:"login"},form));setTimeout(()=>u.focus(),50)}

/* ---------- data ---------- */
function loadData(){BASE=clone(window.NITI_DATA);D=null;hadDraft=false;const dr=draftData();if(dr){D=dr;hadDraft=true}
  if(!D)D=clone(BASE);D.site=Object.assign({},BASE.site,D.site);D.config=Object.assign({},BASE.config,D.config);D.reviews=D.reviews||[]}
let st;function save(){clearTimeout(st);st=setTimeout(persist,250)}
function persist(){if(!D)return;try{localStorage.setItem("niti_draft",JSON.stringify(D))}catch(e){toast("Penyimpanan draft penuh. Unduh data.js sekarang atau kecilkan foto.",1)}updStatus()}
function updStatus(){const changed=JSON.stringify(D)!==JSON.stringify(BASE);const s=$("#status");if(!s)return;
  s.innerHTML=`<span class="dot ${changed?"warn":""}"></span>${changed?"Ada perubahan belum terbit":"Sama dengan data situs"}`;renderStat()}

/* ---------- gambar ---------- */
function compress(file,max=1100,q=.82){return new Promise((res,rej)=>{const r=new FileReader();r.onerror=rej;r.onload=()=>{const im=new Image();im.onerror=rej;im.onload=()=>{const s=Math.min(1,max/Math.max(im.width,im.height));const w=Math.round(im.width*s),hh=Math.round(im.height*s);const c=document.createElement("canvas");c.width=w;c.height=hh;const x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,w,hh);x.drawImage(im,0,0,w,hh);res(c.toDataURL("image/jpeg",q))};im.src=r.result};r.readAsDataURL(file)})}
const kb=s=>s&&s.startsWith("data:")?Math.round(s.length*.75/1024)+" KB":"";
function imgPicker(val,onch,max=1100){
  let cur=val||"";
  const prev=h("img",{class:"prev",alt:"",src:cur||PH});prev.onerror=()=>{prev.src=PH};
  const info=h("small",{class:"hint"},kb(cur)||(cur?cur:"Belum ada foto"));
  const set=v=>{cur=v;prev.src=cur||PH;info.textContent=kb(cur)||cur||"Belum ada foto";onch(cur)};
  const file=h("input",{type:"file",accept:"image/*",hidden:true,onchange:async e=>{const f=e.target.files[0];if(!f)return;try{set(await compress(f,max));toast("Foto dimuat dan dikecilkan")}catch(_){toast("Foto tidak bisa dibaca, coba file lain",1)}e.target.value=""}});
  const txt=h("input",{type:"text",placeholder:"img/foto.jpg atau https://…",value:cur.startsWith("data:")?"":cur,oninput:e=>set(e.target.value.trim())});
  return h("div",{class:"imgp"},prev,h("div",{class:"ia"},
    h("div",{class:"r"},h("label",{class:"btn red sm",style:"cursor:pointer"},"📷 Pilih / Ganti Foto",file),h("button",{type:"button",class:"btn sm danger",onclick:()=>set("")},"Hapus")),
    info,h("details",{},h("summary",{},"Atau tempel alamat gambar"),txt)))}

/* ---------- field helpers ---------- */
const F=(label,input,hint)=>h("div",{class:"f"},h("label",{},label),input,hint&&h("span",{class:"hint"},hint));
const T=(o,k,ph="",type="text")=>h("input",{type,placeholder:ph,value:o[k]??"",oninput:e=>{o[k]=type==="number"?(e.target.value===""?"":+e.target.value):e.target.value;}});
const A=(o,k,ph="",rows)=>h("textarea",{placeholder:ph,rows,oninput:e=>{o[k]=e.target.value}},o[k]??"");
const C=(o,k,label)=>h("label",{class:"chk"},h("input",{type:"checkbox",checked:o[k],onchange:e=>{o[k]=e.target.checked}}),label);

/* ---------- kerangka panel ---------- */
function showPanel(){loadData();built=true;const v=$("#view");v.innerHTML=`
<header class="top">
  <div class="bar">
    <div class="brand"><img class="logo" src="img/logo-niti.png" alt="Niti"><div><b>Panel Pemilik</b><small id="status"><span class="dot"></span>Memuat…</small></div></div>
    <div class="hacts"><button class="btn sm" id="btnSite"><span class="hide-m">← Lihat Situs</span><span class="show-m">← Situs</span></button><button class="btn sm" id="btnPrev">👁 <span class="hide-m">Pratinjau</span></button><button class="btn red sm" id="btnPub">Terbitkan</button><button class="btn sm danger" id="btnOut" title="Keluar dari panel">Keluar</button></div>
  </div>
  <nav class="tabs" id="tabs" role="tablist">
    <button data-t="produk" class="on">🛒 Produk</button><button data-t="ulasan">⭐ Ulasan</button><button data-t="situs">🖼 Teks &amp; Foto</button><button data-t="toko">🏪 Info Toko</button><button data-t="terbit">🚀 Terbitkan</button>
  </nav>
</header>
<main>
  <section class="panel on" id="p-produk">
    <div class="head"><div><h2>Produk &amp; Harga</h2><p>Ubah nama, harga, foto, stok. Urutan di sini = urutan di katalog.</p></div>
      <div class="tools"><input class="search" id="pq" type="search" placeholder="Cari produk…"><button class="btn red" id="addP">+ Produk</button></div></div>
    <div class="grid" id="plist"></div>
  </section>
  <section class="panel" id="p-ulasan">
    <div class="head"><div><h2>Ulasan Pelanggan</h2><p>Tambah atau ubah testimoni yang tampil di situs.</p></div><div class="tools"><button class="btn red" id="addR">+ Ulasan</button></div></div>
    <div class="grid" id="rlist"></div>
  </section>
  <section class="panel" id="p-situs"><div id="siteForm"></div></section>
  <section class="panel" id="p-toko"><div id="shopForm"></div></section>
  <section class="panel" id="p-terbit">
    <div class="head"><div><h2>Terbitkan Perubahan</h2><p>Perubahan tersimpan otomatis sebagai draft di perangkat ini. Agar pengunjung ikut melihat, unggah file data.js ke hosting.</p></div></div>
    <div class="pub">
      <div class="fgrp"><h3>Cara menerbitkan</h3><p class="d">Cukup 3 langkah:</p>
        <ol class="steps">
          <li><div><b>Cek dulu lewat Pratinjau.</b><br><span class="hint">Membuka situs dengan perubahan Anda, hanya terlihat di perangkat ini.</span></div></li>
          <li><div><b>Unduh data.js.</b><br><span class="hint">File ini berisi seluruh harga, teks, foto, dan login admin terbaru.</span></div></li>
          <li><div><b>Unggah &amp; timpa data.js lama</b> di hosting (folder yang sama dengan index.html).<br><span class="hint">Selesai. Tekan refresh di situs, dan perubahan langsung tampil untuk semua pengunjung.</span></div></li>
        </ol>
        <div class="stat" id="stat"></div>
      </div>
      <div class="fgrp"><h3>Aksi</h3>
        <div class="pubbtns">
          <button class="btn" id="bPrev">👁 Pratinjau di Situs</button>
          <button class="btn red" id="bDl">⬇ Unduh data.js</button>
          <button class="btn" id="bBk">💾 Unduh Cadangan (.json)</button>
          <label class="btn" style="cursor:pointer">📂 Pulihkan dari Cadangan<input type="file" id="bImp" accept=".json,.js" hidden></label>
          <button class="btn danger" id="bReset">↺ Buang Draft (kembali ke data situs)</button>
        </div>
        <p class="hint" style="margin-top:12px">Panel ini tidak mengubah situs secara langsung. Perubahan baru tampil untuk pengunjung setelah data.js diunggah ke hosting.</p>
      </div>
    </div>
    <div class="note" style="margin-top:6px">Foto yang Anda unggah dikecilkan otomatis (maks. 1100–1400 px) dan disimpan di dalam data.js. Jika file terasa besar (&gt; 4 MB), hapus foto yang tidak terpakai.</div>
  </section>
</main>`;
  $("#tabs").onclick=e=>{const b=e.target.closest("button");if(b)tab(b.dataset.t)};
  $("#btnPub").onclick=()=>tab("terbit");$("#btnSite").onclick=close;$("#btnOut").onclick=()=>{if(confirm("Keluar dari Panel Pemilik? Draft tetap tersimpan di perangkat ini."))logout()};
  $("#btnPrev").onclick=preview;$("#bPrev").onclick=preview;
  $("#bDl").onclick=()=>{persist();dl("data.js",dataJs(),"text/javascript");toast("data.js diunduh. Unggah ke hosting untuk menerbitkan.")};
  $("#bBk").onclick=()=>{dl("cadangan-niti-"+new Date().toISOString().slice(0,10)+".json",JSON.stringify(D),"application/json");toast("Cadangan diunduh")};
  $("#bImp").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const t=await f.text();const o=JSON.parse(t.slice(t.indexOf("{"),t.lastIndexOf("}")+1));if(!o.products)throw 0;if(!confirm("Timpa draft sekarang dengan isi file ini?"))return;D=o;D.site=Object.assign({},BASE.site,D.site);D.config=Object.assign({},BASE.config,D.config);persist();renderAll();toast("Data dipulihkan")}catch(_){toast("File tidak dikenali. Pakai file cadangan .json atau data.js",1)}e.target.value=""};
  $("#bReset").onclick=()=>{if(!confirm("Buang semua perubahan draft dan kembali ke data situs saat ini?"))return;D=clone(BASE);try{localStorage.removeItem("niti_draft");localStorage.removeItem("niti_preview")}catch(e){}renderAll();updStatus();toast("Draft dibuang")};
  $("#addP").onclick=()=>editProduct(null);$("#pq").oninput=renderProducts;$("#addR").onclick=()=>editReview(null);
  renderAll();
  if(hadDraft&&JSON.stringify(D)!==JSON.stringify(BASE))toast("Draft sebelumnya dipulihkan");
  if(!showPanel.bound){window.addEventListener("beforeunload",()=>{if(built)persist()});showPanel.bound=true}}
function tab(t){$$("#tabs button").forEach(b=>b.classList.toggle("on",b.dataset.t===t));$$(".panel").forEach(p=>p.classList.toggle("on",p.id==="p-"+t));host.scrollTop=0}

/* ---------- dialog ---------- */
function openDlg(title,body,onSave,extraBtn){
  const d=$("#dlg");d.innerHTML="";
  const form=h("form",{method:"dialog",onsubmit:e=>{e.preventDefault();const r=onSave();if(r!==false)d.close()}},
    h("div",{class:"dh"},h("h3",{},title),h("button",{type:"button",class:"btn icon sm",onclick:()=>d.close(),"aria-label":"Tutup"},"✕")),
    h("div",{class:"db"},body),
    h("div",{class:"df"},extraBtn,h("button",{type:"button",class:"btn",onclick:()=>d.close()},"Batal"),h("button",{type:"submit",class:"btn red"},"Simpan")));
  d.append(form);d.showModal();$(".db",d).scrollTop=0}

/* ---------- PRODUK ---------- */
const STATUS={ready:["Tersedia",""],habis:["Stok Habis","out"],sembunyi:["Disembunyikan","hide"]};
function renderProducts(){
  const q=$("#pq").value.trim().toLowerCase(),box=$("#plist");box.innerHTML="";let n=0;
  D.products.forEach((p,i)=>{if(q&&!(p.name||"").toLowerCase().includes(q))return;n++;
    const [sl,sc]=STATUS[p.status||"ready"];
    box.append(h("article",{class:"card pc"},
      h("div",{class:"ph"},h("img",{src:p.img||PH,alt:"",loading:"lazy",onerror:e=>{e.target.src=PH}})),
      h("div",{class:"b"},h("h3",{},p.name||"(tanpa nama)"),
        h("div",{class:"price"},rp(p.price),p.old?h("s",{},rp(p.old)):null,h("span",{style:"font:12px var(--sans);color:var(--muted);margin-left:8px"},p.unit||"")),
        h("div",{class:"chips"},h("span",{class:"chip "+sc},sl),p.featured&&h("span",{class:"chip fe"},"★ Beranda"),h("span",{class:"chip",style:"background:#efe8e3;color:#6b5a50"},p.kat||"")),
        h("div",{class:"acts"},h("button",{class:"btn red sm",onclick:()=>editProduct(i)},"✎ Edit"),
          h("button",{class:"btn sm icon",title:"Naik","aria-label":"Naikkan",onclick:()=>move(D.products,i,-1,renderProducts)},"↑"),
          h("button",{class:"btn sm icon",title:"Turun","aria-label":"Turunkan",onclick:()=>move(D.products,i,1,renderProducts)},"↓"),
          h("button",{class:"btn sm",title:"Duplikat",onclick:()=>dupProduct(i)},"⎘"),
          h("button",{class:"btn sm icon danger",title:"Hapus","aria-label":"Hapus",onclick:()=>{if(confirm(`Hapus produk "${p.name}"?`)){D.products.splice(i,1);save();renderProducts()}}},"🗑")))))});
  if(!n)box.append(h("div",{class:"empty"},q?"Tidak ada produk yang cocok.":"Belum ada produk. Tekan “+ Produk”."))}
function move(arr,i,d,after){const j=i+d;if(j<0||j>=arr.length)return;[arr[i],arr[j]]=[arr[j],arr[i]];save();after()}
function dupProduct(i){const c=clone(D.products[i]);c.id=Math.max(0,...D.products.map(p=>p.id))+1;c.name+=" (salinan)";c.sku=(c.sku||"")+"-2";D.products.splice(i+1,0,c);save();renderProducts();toast("Produk diduplikat")}
function editProduct(i){
  const isNew=i==null;
  const p=isNew?{id:Math.max(0,...D.products.map(x=>x.id))+1,name:"",unit:"",price:"",kat:"Camilan Tradisional",img:"",gallery:[],rating:5,sold:"0",sku:"",desc:"",long:"",taste:[["",""],["",""]],status:"ready",featured:false}:clone(D.products[i]);
  p.taste=p.taste||[["",""],["",""]];while(p.taste.length<2)p.taste.push(["",""]);p.gallery=p.gallery||[];
  const cats=[...new Set(D.products.map(x=>x.kat).filter(Boolean))];
  const gal=h("div",{class:"gal"});
  const drawGal=()=>{gal.innerHTML="";p.gallery.forEach((g,k)=>{const it=h("div",{class:"it"},imgPicker(g,v=>{p.gallery[k]=v},1100),h("button",{type:"button",class:"btn sm icon danger x",onclick:()=>{p.gallery.splice(k,1);drawGal()},"aria-label":"Hapus foto"},"✕"));gal.append(it)});
    gal.append(h("button",{type:"button",class:"btn sm",onclick:()=>{p.gallery.push("");drawGal()}},"+ Tambah Foto Galeri"))};
  drawGal();
  const body=h("div",{},
    h("h4",{},"Informasi Utama"),
    F("Nama Produk *",Object.assign(T(p,"name","Contoh: Keripik Tempe Original"),{required:true})),
    h("div",{class:"row"},F("Harga (Rp) *",Object.assign(T(p,"price","30000","number"),{required:true,min:0,step:500,inputMode:"numeric"})),F("Harga Coret (opsional)",Object.assign(T(p,"old","Mis. 35000","number"),{min:0,step:500,inputMode:"numeric"}),"Isi jika sedang diskon; harga lama tampil dicoret.")),
    h("div",{class:"row"},F("Ukuran / Isi",T(p,"unit","170 gr, isi 5 pouch")),F("Kategori",(()=>{const i=T(p,"kat","Pilih atau ketik baru");i.setAttribute("list","cats");return i})())),
    h("datalist",{id:"cats"},cats.map(c=>h("option",{value:c}))),
    h("div",{class:"row"},F("Status Stok",h("select",{onchange:e=>{p.status=e.target.value}},Object.entries(STATUS).map(([k,v])=>h("option",{value:k,selected:(p.status||"ready")===k},v[0]))),"“Stok Habis” menonaktifkan tombol beli. “Disembunyikan” menghilangkan dari situs."),
      h("div",{class:"f"},h("label",{},"Tampilan"),C(p,"featured","Tampilkan di Beranda"))),
    h("h4",{},"Foto"),
    F("Foto Produk (kartu daftar produk)",imgPicker(p.img,v=>{p.img=v},1000),"Gunakan foto persegi atau landscape agar tidak terpotong."),
    F("Galeri Halaman Detail (opsional)",gal,"Foto pertama jadi foto besar. Kosongkan jika cukup memakai foto produk di atas."),
    h("h4",{},"Deskripsi"),
    F("Deskripsi Singkat (di kartu)",A(p,"desc","Satu-dua kalimat menarik.",3)),
    F("Deskripsi Lengkap (halaman detail)",A(p,"long","Cerita, bahan, dan keunggulan produk.",5)),
    h("h4",{},"Keunggulan di Halaman Detail"),
    h("div",{class:"row"},[0,1].map(k=>h("div",{},F(`Keunggulan ${k+1}: judul`,h("input",{type:"text",value:p.taste[k][0],oninput:e=>{p.taste[k][0]=e.target.value}})),F("Keterangan",h("input",{type:"text",value:p.taste[k][1],oninput:e=>{p.taste[k][1]=e.target.value}}))))),
    h("h4",{},"Lainnya"),
    h("div",{class:"row three"},F("Kode Produk (SKU)",T(p,"sku","NIT-ORG-170")),F("Rating (1–5)",Object.assign(T(p,"rating","4.9","number"),{min:1,max:5,step:.1})),F("Terjual / Ulasan",T(p,"sold","340+"))));
  const delBtn=isNew?null:h("button",{type:"button",class:"btn danger",style:"margin-right:auto",onclick:()=>{if(confirm(`Hapus produk "${p.name}"?`)){D.products.splice(i,1);save();renderProducts();$("#dlg").close()}}},"🗑 Hapus");
  openDlg(isNew?"Produk Baru":"Edit Produk",body,()=>{
    if(!String(p.name).trim()){toast("Nama produk wajib diisi",1);return false}
    if(p.price===""||p.price<0){toast("Harga wajib diisi",1);return false}
    p.price=+p.price;if(p.old===""||!p.old)delete p.old;else p.old=+p.old;p.rating=+p.rating||5;
    p.gallery=p.gallery.filter(Boolean);if(!p.gallery.length)delete p.gallery;
    if(!p.sku)p.sku="NIT-"+String(p.id).padStart(3,"0");
    p.taste=p.taste.filter(t=>t[0]||t[1]);if(!p.img&&!(p.gallery&&p.gallery[0])){toast("Tambahkan minimal satu foto produk",1);return false}if(!p.img)p.img=p.gallery[0];
    if(isNew)D.products.push(p);else D.products[i]=p;save();renderProducts();toast("Produk disimpan")},delBtn)}

/* ---------- ULASAN ---------- */
function renderReviews(){const box=$("#rlist");box.innerHTML="";
  D.reviews.forEach((r,i)=>box.append(h("article",{class:"card rc"},
    h("div",{class:"who"},h("span",{class:"av"},(r.n||"?")[0].toUpperCase()),h("div",{},h("b",{},r.n||"(tanpa nama)"),h("br"),h("small",{style:"color:var(--muted)"},r.c||""))),
    h("div",{class:"st"},"★".repeat(r.s||5)),h("p",{},"“"+(r.t||"")+"”"),
    h("div",{class:"chips"},r.home&&h("span",{class:"chip fe"},"★ Beranda"),r.img&&h("span",{class:"chip"},"📷 Foto"),r.v&&h("span",{class:"chip",style:"background:#efe8e3;color:#6b5a50"},r.v)),
    h("div",{class:"acts"},h("button",{class:"btn red sm",onclick:()=>editReview(i)},"✎ Edit"),h("button",{class:"btn sm icon",onclick:()=>move(D.reviews,i,-1,renderReviews),"aria-label":"Naik"},"↑"),h("button",{class:"btn sm icon",onclick:()=>move(D.reviews,i,1,renderReviews),"aria-label":"Turun"},"↓"),
      h("button",{class:"btn sm icon danger","aria-label":"Hapus",onclick:()=>{if(confirm("Hapus ulasan ini?")){D.reviews.splice(i,1);save();renderReviews()}}},"🗑")))));
  if(!D.reviews.length)box.append(h("div",{class:"empty"},"Belum ada ulasan."))}
function editReview(i){const isNew=i==null;
  const r=isNew?{n:"",c:"",v:"",s:5,t:"",f:"",w:"Baru saja",home:false,img:""}:clone(D.reviews[i]);
  const body=h("div",{},
    h("div",{class:"row"},F("Nama Pelanggan *",Object.assign(T(r,"n","Contoh: Ibu Linda"),{required:true})),F("Kota",T(r,"c","Jakarta Selatan, DKI"))),
    h("div",{class:"row"},F("Produk yang Dibeli",T(r,"v","Original 170g")),F("Bintang",h("select",{onchange:e=>{r.s=+e.target.value}},[5,4,3,2,1].map(n=>h("option",{value:n,selected:r.s===n},"★".repeat(n)+" ("+n+")"))))),
    F("Isi Ulasan *",Object.assign(A(r,"t","Tulis ulasan pelanggan…",5),{required:true})),
    h("div",{class:"row"},F("Keterangan Bawah",T(r,"f","Ekspedisi Regular (2 hari)")),F("Waktu",T(r,"w","1 minggu lalu"))),
    F("Foto Pelanggan (opsional)",imgPicker(r.img,v=>{r.img=v},900)),
    C(r,"home","Tampilkan di Beranda (maks. 3 ulasan)"));
  openDlg(isNew?"Ulasan Baru":"Edit Ulasan",body,()=>{
    if(!r.n.trim()||!r.t.trim()){toast("Nama dan isi ulasan wajib diisi",1);return false}
    r.l=r.n.trim()[0].toUpperCase();if(!r.img)delete r.img;
    if(isNew)D.reviews.unshift(r);else D.reviews[i]=r;
    D.reviews.forEach((x,k)=>x.cls=["","g","p"][k%3]);save();renderReviews();toast("Ulasan disimpan")})}

/* ---------- TEKS & FOTO ---------- */
const SITE_GROUPS=[
 ["Bilah Atas","Tulisan tipis di paling atas setiap halaman.",[["topbar","Teks Bilah Atas","t"]]],
 ["Beranda: Bagian Utama (Hero)","Judul dan foto pertama yang dilihat pengunjung. Bungkus kata dengan *bintang* untuk membuatnya miring &amp; emas.",[
   ["heroPill","Label Kecil","t"],["heroTitle","Judul Besar","a"],["heroLead","Paragraf Pembuka","a"],["heroImg","Foto Hero","i",1400],["heroTagSmall","Label di Foto (kecil)","t"],["heroTagText","Label di Foto (besar)","t"],["sealSmall","Stempel: teks atas","t"],["sealBig","Stempel: tahun/angka","t"]]],
 ["Beranda: Tiga Angka","Angka ringkas di bawah hero.",[["stat1v","Angka 1","t"],["stat1l","Keterangan 1","t"],["stat2v","Angka 2","t"],["stat2l","Keterangan 2","t"],["stat3v","Angka 3","t"],["stat3l","Keterangan 3","t"]]],
 ["Foto-Foto Situs","Foto yang tampil di beranda dan halaman Cerita Kami. (Peta lokasi kini memakai Google Maps langsung; atur di menu Info Toko.)",[["storyImg1","Foto Pendiri (Beranda)","i",1200],["storyImg2","Foto Lawas/Keluarga (Beranda)","i",1200],["visitImg","Foto Toko/Pabrik (Beranda)","i",1400],["aboutImg","Foto Pendiri (Halaman Cerita Kami)","i",1200]]],
 ["Kutipan Pelanggan Besar","Kutipan di tengah beranda.",[["bigQuote","Isi Kutipan","a"],["bigQuoteBy","Nama","t"],["bigQuoteSub","Keterangan","t"]]],
 ["Halaman Ulasan: Skor","Ringkasan rating di halaman Ulasan.",[["ratingScore","Skor (mis. 4.9)","t"],["ratingNote","Keterangan Skor","a"],["bars","Persentase Bintang","bars"]]],
 ["Ajakan Memesan (Banner Merah)","Muncul di beranda dan halaman ulasan.",[["ctaTitle","Judul","t"],["ctaText","Teks","a"]]]
];
function renderSite(){const root=$("#siteForm");root.innerHTML="";
  root.append(h("div",{class:"head"},h("div",{},h("h2",{},"Teks & Foto Situs"),h("p",{},"Ubah kalimat dan gambar utama di halaman Beranda dan sekitarnya. Teks panjang di halaman Kenali Niti dan Cerita Kami diubah langsung di file HTML-nya."))));
  SITE_GROUPS.forEach(([title,desc,fields])=>{
    const g=h("div",{class:"fgrp"},h("h3",{},title),h("p",{class:"d",html:desc}));
    let row=null;
    fields.forEach(([k,label,type,max])=>{
      if(type==="t"){if(!row){row=h("div",{class:"row"});g.append(row)}row.append(F(label,T(D.site,k)));return}
      row=null;
      if(type==="a")g.append(F(label,A(D.site,k,"",3)));
      else if(type==="i")g.append(F(label,imgPicker(D.site[k],v=>{D.site[k]=v;save()},max)));
      else if(type==="bars"){const w=h("div",{class:"row three"});D.site.bars=D.site.bars||[88,10,2,0,0];[5,4,3,2,1].forEach((n,j)=>w.append(F(`${n} bintang (%)`,Object.assign(h("input",{type:"number",min:0,max:100,value:D.site.bars[j],oninput:e=>{D.site.bars[j]=+e.target.value||0}}),{inputMode:"numeric"}))));g.append(w)}
    });
    root.append(g)});
  root.oninput=save;root.onchange=save}

/* ---------- INFO TOKO ---------- */
function normWA(v){let d=String(v).replace(/\D/g,"");if(d.startsWith("0"))d="62"+d.slice(1);else if(d.startsWith("8"))d="62"+d;return d}
function dispWA(d){const r=d.startsWith("62")?d.slice(2):d;return "+62 "+r.slice(0,3)+"-"+r.slice(3,7)+(r.length>7?"-"+r.slice(7):"")}
function renderShop(){const root=$("#shopForm"),c=D.config;root.innerHTML="";
  const wa=h("input",{type:"tel",inputmode:"tel",placeholder:"0812-3456-7890",value:c.waNumber?"+"+c.waDisplay.replace(/^\+/,""):"",oninput:e=>{const d=normWA(e.target.value);c.waNumber=d;c.waDisplay=d?dispWA(d):"";prev.textContent=d?`Tombol pesan akan membuka wa.me/${d}`:"Nomor belum diisi"}});
  const prev=h("span",{class:"hint"},`Tombol pesan akan membuka wa.me/${c.waNumber}`);
  const mapFrame=h("iframe",{class:"mapprev",title:"Pratinjau peta",loading:"lazy",src:gmapEmbed(c.mapsQuery||c.address)});
  let mt;const mapIn=h("textarea",{rows:2,placeholder:"Contoh: Tempe Kripik Niti Purwokerto",oninput:e=>{c.mapsQuery=e.target.value.trim();clearTimeout(mt);mt=setTimeout(()=>{mapFrame.src=gmapEmbed(c.mapsQuery||c.address)},700)}},c.mapsQuery||"");
  /* akun admin */
  const nu=h("input",{type:"text",autocomplete:"username",autocapitalize:"none",placeholder:"Username baru"});
  const np=h("input",{type:"password",autocomplete:"new-password",placeholder:"Minimal 6 karakter"});
  const np2=h("input",{type:"password",autocomplete:"new-password",placeholder:"Ulangi password baru"});
  const setAcc=h("button",{type:"button",class:"btn red",onclick:()=>{
    if(!nu.value.trim()){toast("Username wajib diisi",1);return}
    if(np.value.length<6){toast("Password minimal 6 karakter",1);return}
    if(np.value!==np2.value){toast("Ulangi password tidak sama",1);return}
    c.adminHash=credHash(nu.value,np.value);persist();np.value=np2.value="";
    toast("Login baru disimpan. Terbitkan data.js agar berlaku di semua perangkat.")}},"Simpan Login Baru");
  root.append(h("div",{class:"head"},h("div",{},h("h2",{},"Info Toko"),h("p",{},"Nomor WhatsApp, alamat, peta, media sosial, dan akun admin."))),
    h("div",{class:"fgrp"},h("h3",{},"WhatsApp Pemesanan"),h("p",{class:"d"},"Semua pesanan dari keranjang masuk ke nomor ini."),
      F("Nomor WhatsApp",wa),prev,h("div",{style:"height:10px"}),F("Nama Toko",T(c,"store"),"Dipakai di awal pesan WhatsApp.")),
    h("div",{class:"fgrp"},h("h3",{},"Lokasi & Jam Buka"),
      F("Alamat Lengkap",A(c,"address","",3)),F("Jam Buka",T(c,"hours","Setiap hari, 08.00 – 21.00 WIB")),F("Tautan Tombol “Petunjuk Arah”",T(c,"mapsUrl","https://maps.google.com/…","url"),"Buka Google Maps, cari lokasi toko, tekan Bagikan, salin tautannya."),
      F("Peta Google Maps (halaman Cerita Kami)",mapIn,"Ketik nama tempat persis seperti di Google Maps, atau tempel kode dari Google Maps › Bagikan › Sematkan peta. Pengunjung bisa zoom & geser peta."),mapFrame),
    h("div",{class:"fgrp"},h("h3",{},"Media Sosial"),
      h("div",{class:"row"},F("Tautan Instagram",T(c,"instagram","https://instagram.com/…","url")),F("Nama Instagram",T(c,"instagramHandle","@namaanda"))),
      h("div",{class:"row"},F("Tautan TikTok",T(c,"tiktok","https://tiktok.com/@…","url")),F("Nama TikTok",T(c,"tiktokHandle","@namaanda")))),
    h("div",{class:"fgrp"},h("h3",{},"Akun Admin"),h("p",{class:"d"},"Ganti username & password untuk masuk ke panel ini. Langsung berlaku di perangkat ini; untuk perangkat lain, terbitkan data.js."),
      h("div",{class:"row three"},F("Username Baru",nu),F("Password Baru",np),F("Ulangi Password",np2)),setAcc));
  root.oninput=save}

/* ---------- TERBITKAN ---------- */
const dataJs=()=>"/* DATA SITUS — dibuat oleh Panel Pemilik pada "+new Date().toLocaleString("id-ID")+". Unggah file ini untuk menimpa data.js di hosting. */\nwindow.NITI_DATA = "+JSON.stringify(D)+";\n";
function dl(name,text,type){const a=h("a",{href:URL.createObjectURL(new Blob([text],{type})),download:name});document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)}
function renderStat(){const s=$("#stat");if(!s)return;const size=(dataJs().length/1024/1024);s.innerHTML=`<div><b>${D.products.length}</b><small>Produk</small></div><div><b>${D.reviews.length}</b><small>Ulasan</small></div><div><b>${size<0.1?Math.round(size*1024)+" KB":size.toFixed(1)+" MB"}</b><small>Ukuran data.js</small></div>`}
function preview(){persist();try{localStorage.setItem("niti_preview","1")}catch(e){toast("Tidak bisa membuka pratinjau: penyimpanan penuh",1);return}
  close();location.reload()}
function renderAll(){renderProducts();renderReviews();renderSite();renderShop();updStatus()}

return {open,close};
})();
